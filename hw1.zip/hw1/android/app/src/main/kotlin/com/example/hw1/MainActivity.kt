package com.example.hw1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
